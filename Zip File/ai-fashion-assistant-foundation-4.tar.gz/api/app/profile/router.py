from __future__ import annotations

from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from api.app.auth.dependencies import current_user_id
from api.app.auth.internal import require_internal_service
from api.app.core.dependencies import db_session, object_storage, profile_media_repository, profile_photo_queue
from api.app.profile.application.media_use_cases import ProfileMediaApplicationService
from api.app.profile.application.profile_use_cases import ProfileApplicationService
from api.app.profile.repositories.media import ProfileMediaRepository
from api.app.profile.repositories.profile import ProfileRepository
from api.app.ports.queue import QueuePort
from api.app.ports.storage import ObjectStoragePort
from schemas.identity.consent import ConsentRecord, ConsentUpdate
from schemas.identity.media import (
    MediaAccessRequest,
    MediaAccessResponse,
    PhotoCompleteResponse,
    PhotoCreateRequest,
    PhotoCreateResponse,
    PhotoStatusResponse,
)
from schemas.identity.user import UserRef
from schemas.profile.body import BodyProfile
from schemas.profile.derived import DerivedProfile
from schemas.profile.profile import ProfileCreateRequest, ProfileResponse
from schemas.profile.preferences import UserPreferences

router = APIRouter(prefix="/api/v1/profile", tags=["profile"])


def get_service(session: AsyncSession = Depends(db_session)) -> ProfileApplicationService:
    return ProfileApplicationService(ProfileRepository(session))


def get_media_service(
    repository: ProfileMediaRepository = Depends(profile_media_repository),
    storage: ObjectStoragePort = Depends(object_storage),
    queue: QueuePort = Depends(profile_photo_queue),
) -> ProfileMediaApplicationService:
    return ProfileMediaApplicationService(repository, storage, queue)


@router.post("", response_model=UserRef, status_code=status.HTTP_201_CREATED)
async def create_profile(
    payload: ProfileCreateRequest,
    user_id=Depends(current_user_id),
    service: ProfileApplicationService = Depends(get_service),
) -> UserRef:
    await service.update_profile(
        user_id,
        height_cm=payload.height_cm,
        weight_kg=payload.weight_kg,
        build=payload.build,
        colors_favored=payload.colors_favored,
        colors_avoided=payload.colors_avoided,
        categories=payload.categories,
        budget_min=payload.budget_min,
        budget_max=payload.budget_max,
    )
    return UserRef(user_id=user_id)


@router.get("/me", response_model=ProfileResponse)
async def get_my_profile(
    user_id=Depends(current_user_id),
    service: ProfileApplicationService = Depends(get_service),
) -> ProfileResponse:
    user, body, preferences = await service.get_profile(user_id)
    return ProfileResponse(
        user_id=user.id,
        created_at=user.created_at,
        body=BodyProfile.model_validate(body, from_attributes=True) if body else BodyProfile(),
        preferences=UserPreferences.model_validate(preferences, from_attributes=True) if preferences else UserPreferences(),
    )


@router.get("/{user_id}/derived", response_model=DerivedProfile)
async def get_derived_profile(
    user_id,
    requester_id=Depends(current_user_id),
    service: ProfileApplicationService = Depends(get_service),
) -> DerivedProfile:
    if requester_id != user_id:
        from api.app.core.errors import AuthorizationError
        raise AuthorizationError("Derived profile access denied")
    body, preferences, style = await service.get_derived(user_id)
    style_vector = list(style.embedding) if style and style.embedding else None
    return DerivedProfile(
        skin_tone_class=None,
        style_vector=style_vector,
        preferences={
            "colors_favored": getattr(preferences, "colors_favored", []),
            "colors_avoided": getattr(preferences, "colors_avoided", []),
            "categories": getattr(preferences, "categories", []),
            "budget_min": getattr(preferences, "budget_min", None),
            "budget_max": getattr(preferences, "budget_max", None),
        },
    )


@router.post("/consent", response_model=ConsentRecord)
async def set_consent(
    payload: ConsentUpdate,
    user_id=Depends(current_user_id),
    service: ProfileMediaApplicationService = Depends(get_media_service),
) -> ConsentRecord:
    record = await service.set_consent(user_id, data_type=payload.data_type, granted=payload.granted)
    return ConsentRecord(user_id=user_id, data_type=payload.data_type, granted=record.granted, updated_at=record.updated_at)


@router.post("/me/photos", response_model=PhotoCreateResponse, status_code=status.HTTP_201_CREATED)
async def create_photo_upload(
    payload: PhotoCreateRequest,
    user_id=Depends(current_user_id),
    service: ProfileMediaApplicationService = Depends(get_media_service),
) -> PhotoCreateResponse:
    photo, upload_url, expires_at = await service.create_photo_upload(
        user_id,
        photo_type=payload.photo_type,
        content_type=payload.content_type,
        file_size_bytes=payload.file_size_bytes,
    )
    return PhotoCreateResponse(
        photo_id=photo.id,
        status=photo.status,
        upload_url=upload_url,
        expires_at=expires_at,
    )


@router.post("/me/photos/{photo_id}/complete", response_model=PhotoCompleteResponse, status_code=status.HTTP_202_ACCEPTED)
async def complete_photo_upload(
    photo_id,
    user_id=Depends(current_user_id),
    service: ProfileMediaApplicationService = Depends(get_media_service),
) -> PhotoCompleteResponse:
    photo, job = await service.complete_photo_upload(user_id, photo_id)
    return PhotoCompleteResponse(photo_id=photo.id, status=photo.status, processing_job_id=job.id)


@router.get("/me/photos/{photo_id}", response_model=PhotoStatusResponse)
async def get_photo_status(
    photo_id,
    user_id=Depends(current_user_id),
    service: ProfileMediaApplicationService = Depends(get_media_service),
) -> PhotoStatusResponse:
    photo = await service.get_photo_status(user_id, photo_id)
    return PhotoStatusResponse(
        photo_id=photo.id,
        photo_type=photo.photo_type,
        status=photo.status,
        reject_reason=photo.reject_reason,
        version=photo.version,
        created_at=photo.created_at,
    )


@router.post("/internal/media-access", response_model=MediaAccessResponse, dependencies=[Depends(require_internal_service)])
async def create_scoped_media_access(
    payload: MediaAccessRequest,
    service: ProfileMediaApplicationService = Depends(get_media_service),
) -> MediaAccessResponse:
    access_url, expires_at = await service.create_scoped_media_url(
        photo_id=payload.photo_id,
        purpose=payload.purpose,
        job_id=payload.job_id,
    )
    return MediaAccessResponse(
        photo_id=payload.photo_id,
        access_url=access_url,
        expires_at=expires_at,
        purpose=payload.purpose,
        job_id=payload.job_id,
    )
