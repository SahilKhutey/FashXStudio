from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class ProfilePhotoJobResponse(BaseModel):
    job_id: UUID
    photo_id: UUID
    status: str
    failure_reason: str | None = None
    created_at: datetime
