from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO

import cv2
import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError


@dataclass(frozen=True)
class PhotoValidationResult:
    accepted: bool
    reason: str | None
    content_sha256: str
    width: int
    height: int
    image_format: str
    mode: str
    has_person: bool | None = None
    has_face: bool | None = None


class PhotoValidationError(ValueError):
    pass


class BasicPhotoValidator:
    """Deterministic media gate before expensive CV/ML processing.

    This intentionally does not claim full pose-landmark correctness. It verifies
    decodability, geometry, and (for the relevant photo types) basic person/face
    presence. A future MediaPipe/TFLite pose adapter can replace the detector
    without changing the worker contract.
    """

    MIN_WIDTH = 512
    MIN_HEIGHT = 512
    MAX_ASPECT_RATIO = 2.5

    def __init__(self) -> None:
        self._face = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        )
        self._hog = cv2.HOGDescriptor()
        self._hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

    def validate(self, payload: bytes, *, photo_type: str) -> PhotoValidationResult:
        digest = sha256(payload).hexdigest()
        try:
            with Image.open(BytesIO(payload)) as image:
                image.verify()
            with Image.open(BytesIO(payload)) as image:
                normalized = ImageOps.exif_transpose(image)
                width, height = normalized.size
                image_format = (normalized.format or image.format or "unknown").lower()
                mode = normalized.mode
                if width < self.MIN_WIDTH or height < self.MIN_HEIGHT:
                    return PhotoValidationResult(
                        False, "insufficient_resolution", digest, width, height, image_format, mode
                    )
                ratio = max(width / height, height / width)
                if ratio > self.MAX_ASPECT_RATIO:
                    return PhotoValidationResult(
                        False, "unsupported_aspect_ratio", digest, width, height, image_format, mode
                    )
                if image_format not in {"jpeg", "jpg", "png", "webp"}:
                    return PhotoValidationResult(
                        False, "unsupported_image_format", digest, width, height, image_format, mode
                    )
        except (UnidentifiedImageError, OSError, ValueError):
            return PhotoValidationResult(False, "invalid_image", digest, 0, 0, "unknown", "unknown")

        image_bgr = cv2.imdecode(np.frombuffer(payload, dtype=np.uint8), cv2.IMREAD_COLOR)
        if image_bgr is None:
            return PhotoValidationResult(False, "invalid_image", digest, 0, 0, "unknown", "unknown")

        gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
        face_boxes = self._face.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80))
        has_face = len(face_boxes) > 0
        has_person = None
        if photo_type == "tryon_reference":
            # HOG person detection is a cheap pre-gate, not the final pose validator.
            _, weights = self._hog.detectMultiScale(
                image_bgr, winStride=(8, 8), padding=(16, 16), scale=1.05
            )
            has_person = bool(len(weights) > 0 and float(np.max(weights)) > 0.25)
            if not has_person:
                return PhotoValidationResult(
                    False,
                    "person_not_detected",
                    digest,
                    width,
                    height,
                    image_format,
                    mode,
                    has_person=False,
                    has_face=has_face,
                )
        elif photo_type == "skin_tone" and not has_face:
            return PhotoValidationResult(
                False,
                "face_not_detected",
                digest,
                width,
                height,
                image_format,
                mode,
                has_person=None,
                has_face=False,
            )

        return PhotoValidationResult(
            True,
            None,
            digest,
            width,
            height,
            image_format,
            mode,
            has_person=has_person,
            has_face=has_face,
        )
