# AI Fashion Assistant

Foundation 0 production-build baseline for the AI Fashion Assistant.

## Scope

Foundation 0 establishes:

- FastAPI application shell
- versioned shared Pydantic contracts
- typed environment configuration
- request/trace IDs
- standard error envelope
- liveness/readiness endpoints
- SQLAlchemy async database foundation
- Alembic migration baseline
- local PostgreSQL + pgvector and Redis
- Sentry integration hook
- pytest / Ruff / mypy CI
- Expo Router mobile shell

No product feature service is implemented yet.

## Requirements

- Python 3.12
- uv 0.12.13+
- Node.js 22.13+
- Docker (for local PostgreSQL/Redis)

## Local backend

```bash
cp .env.example .env
uv sync
uv run pytest
uv run ruff check .
uv run mypy api schemas
uv run fastapi dev api/app/main.py
```

Health endpoints:

- `GET /api/v1/system/health/live`
- `GET /api/v1/system/health/ready`

## Local infrastructure

```bash
docker compose up -d
uv run alembic upgrade head
```

Set `READINESS_REQUIRES_DATABASE=true` after Postgres is available.

## Local mobile shell

```bash
cd mobile
npm install
npx expo start
```

Expo SDK 57 is used for Foundation 0.

## Production principles

- routers do not access the database directly
- shared contracts live in `/schemas`
- migrations are the only schema-change mechanism
- secrets are environment-provided
- raw user media is not part of this foundation
- external vendors are adapter boundaries
