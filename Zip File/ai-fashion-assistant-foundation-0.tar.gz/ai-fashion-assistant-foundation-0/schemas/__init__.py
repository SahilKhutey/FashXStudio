"""Shared versioned wire/domain contracts."""

from .common.errors import ErrorBody, ErrorResponse
from .common.health import HealthResponse
from .common.version import SCHEMA_VERSION

__all__ = ["ErrorBody", "ErrorResponse", "HealthResponse", "SCHEMA_VERSION"]
