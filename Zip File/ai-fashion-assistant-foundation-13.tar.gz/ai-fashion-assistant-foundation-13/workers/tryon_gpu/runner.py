from __future__ import annotations

"""Foundation 13 worker skeleton.

The runner owns the execution lifecycle. The actual model adapter is deliberately
not implemented here; it is introduced only after model/licensing validation.
"""

import asyncio
import json
from uuid import UUID

from api.app.core.database import get_session_factory
from api.app.tryon.repositories.tryon import TryOnRepository
from database.models.tryon import TryOnJob


async def claim_and_process(job_id: UUID) -> None:
    factory = get_session_factory()
    async with factory() as session:
        repository = TryOnRepository(session)
        job = await repository.claim_job(job_id)
        if job is None:
            await session.rollback()
            return
        await session.commit()
        # Foundation 13 stops at the provider boundary. A future runner will
        # transition through VALIDATING → PREPROCESSING → INFERENCE → ... .
        async with factory() as work_session:
            work_repo = TryOnRepository(work_session)
            job = await work_repo.session.get(TryOnJob, job_id)
            if job is None:
                return
            await work_repo.fail(job, reason="tryon_provider_adapter_missing", retryable=False)
            await work_session.commit()


async def consume_once(payload: str) -> None:
    message = json.loads(payload)
    await claim_and_process(UUID(message["job_id"]))


if __name__ == "__main__":
    raise SystemExit("Foundation 13 provides the worker lifecycle contract; queue daemon wiring is introduced with the commercial-approved VTO adapter.")
