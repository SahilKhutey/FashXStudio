from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol
from uuid import UUID


@dataclass(frozen=True, slots=True)
class TryOnSubmission:
    provider_job_id: str


class TryOnProvider(Protocol):
    async def submit(
        self,
        *,
        job_id: UUID,
        profile_photo_url: str,
        garment_image_url: str,
        model_version: str,
        pipeline_version: str,
    ) -> TryOnSubmission: ...


class TryOnProfilePort(Protocol):
    async def get_accepted_photo(self, *, user_id: UUID, photo_id: UUID) -> dict: ...


class TryOnCatalogPort(Protocol):
    async def get_garment_for_tryon(self, *, garment_id: UUID) -> dict: ...
