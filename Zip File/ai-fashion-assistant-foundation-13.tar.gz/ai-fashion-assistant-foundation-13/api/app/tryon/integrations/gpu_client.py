from __future__ import annotations

from typing import Any
from uuid import UUID

from api.app.core.errors import AppError
from api.app.core.settings import get_settings
from api.app.tryon.ports.providers import TryOnProvider, TryOnSubmission


class ConfiguredTryOnProvider(TryOnProvider):
    """Provider boundary for GPU execution.

    Foundation 13 intentionally provides the contract and fail-closed boundary;
    an actual commercial-approved model adapter is introduced in the Try-On
    model implementation stage.
    """

    async def submit(
        self,
        *,
        job_id: UUID,
        profile_photo_url: str,
        garment_image_url: str,
        model_version: str,
        pipeline_version: str,
    ) -> TryOnSubmission:
        settings = get_settings()
        if not settings.tryon_provider:
            raise AppError(
                code="gpu_provider_not_configured",
                message="Try-on GPU provider is not configured",
                status_code=503,
            )
        if settings.tryon_provider == "disabled":
            raise AppError(
                code="gpu_provider_disabled",
                message="Try-on GPU provider is disabled",
                status_code=503,
            )
        # Provider adapters are intentionally deferred to the model implementation stage.
        raise AppError(
            code="tryon_provider_adapter_missing",
            message=f"No production adapter is registered for provider '{settings.tryon_provider}'",
            status_code=503,
        )
