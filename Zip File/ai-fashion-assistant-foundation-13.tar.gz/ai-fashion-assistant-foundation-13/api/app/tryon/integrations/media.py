from __future__ import annotations

from asyncio import to_thread

from api.app.profile.integrations.r2_client import R2StorageClient
from api.app.tryon.integrations.gpu_client import ConfiguredTryOnProvider
from api.app.tryon.ports.providers import TryOnSubmission


class TryOnExecutionGateway:
    def __init__(self, *, storage: R2StorageClient, provider: ConfiguredTryOnProvider) -> None:
        self.storage = storage
        self.provider = provider

    async def submit(self, *, job_id, photo_key, garment_key, model_version, pipeline_version) -> TryOnSubmission:
        photo_url, _ = await to_thread(self.storage.create_download_url, key=photo_key)
        garment_url, _ = await to_thread(self.storage.create_download_url, key=garment_key)
        return await self.provider.submit(
            job_id=job_id,
            profile_photo_url=photo_url,
            garment_image_url=garment_url,
            model_version=model_version,
            pipeline_version=pipeline_version,
        )
