from __future__ import annotations

from uuid import UUID

from api.app.core.errors import NotFoundError
from api.app.catalog.repositories.catalog import CatalogRepository


class LocalCatalogTryOnClient:
    """Modular-monolith adapter; production extraction can replace this with HTTP."""

    def __init__(self, repository: CatalogRepository) -> None:
        self.repository = repository

    async def get_garment_for_tryon(self, *, garment_id: UUID) -> dict:
        garment = await self.repository.get_garment(garment_id)
        if garment is None:
            raise NotFoundError("Try-on garment not found")
        images = await self.repository.get_images(garment_id)
        image = next((x for x in images if x.image_type == "model"), None) or next(
            (x for x in images if x.image_type == "front"), None
        )
        if image is None:
            raise NotFoundError("Garment has no try-on-compatible image")
        return {
            "garment_id": garment.id,
            "version": garment.version,
            "image_key": image.storage_key,
            "image_version": image.version,
            "image_id": image.id,
        }
