from uuid import UUID
from pydantic import BaseModel, Field
from schemas.common.enums import TryOnStatus, TryOnFailureReason


class TryOnWorkerClaim(BaseModel):
    job_id: UUID
    user_id: UUID
    profile_photo_id: UUID
    garment_id: UUID
    status: str
    model_version: str
    pipeline_version: str
    artifact_key: str
    photo_version: int
    garment_version: int


class TryOnWorkerProgress(BaseModel):
    status: TryOnStatus


class TryOnWorkerFailure(BaseModel):
    reason: TryOnFailureReason
    retryable: bool = False


class TryOnWorkerComplete(BaseModel):
    result_key: str = Field(min_length=1)

class TryOnWorkerClaimResponse(TryOnWorkerClaim):
    pass
