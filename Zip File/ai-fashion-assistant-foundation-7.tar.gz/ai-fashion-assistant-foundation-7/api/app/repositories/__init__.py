"""Shared repository abstractions."""
