"""Application-facing dependency ports."""
